<?xml version='1.0' encoding='UTF-8'?>
<data>
<?php $__currentLoopData = $registro; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <item>
        <instrumento><?php echo e($item->Nome); ?></instrumento>
        <categoria><?php echo e($item->Categoria); ?></categoria>
        <marca><?php echo e($item->Marca); ?></marca>
        <material><?php echo e($item->Material); ?></material>
        <preco><?php echo e($item->Preco); ?></preco>
        <dataCadastro><?php echo e($item->Data_Cadastro); ?></dataCadastro>
    </item>
    
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</data>
<?php /**PATH /home/davi/Desktop/pdwa5/projeto_PDWA5/resources/views/data-xml.blade.php ENDPATH**/ ?>